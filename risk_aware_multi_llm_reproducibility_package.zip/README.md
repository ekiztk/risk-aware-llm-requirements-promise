# Risk-Aware Requirements Classification — Reproducibility Package

Generated: 2026-06-19T13:54:13.203669+00:00

## Experiment
- Dataset: PROMISE_exp
- Dataset SHA-256: 7475c2904648912ef08bd1b6149f505f7ce6ab26ee9b187c2ddee28d1af97d75
- Split seed: 42
- Bootstrap seeds: Task A = 20260614; Task B = 20260615
- Bootstrap replicates: 2000
- Prompt version: shared_definitions_examples_v3_no_thinking
- Prompting regime: few-shot, one author-written demonstration per class
- Parser version: strict_exact_label_v1
- LLM limit: None

## Strict output normalization
1. Extract the visible assistant response using the official processor response parser when available.
2. Remove template/control tags, collapse whitespace, strip leading/trailing whitespace, and uppercase.
3. Accept the output only when the entire normalized string equals an allowed label.
4. No manual correction, substring matching, label-name mapping, last-match selection, or semantic fallback is used.

## Decoding
- do_sample: False
- temperature/top_p/top_k: not applicable under greedy decoding
- max_new_tokens: 12
- num_beams: 1
- repetition_penalty: 1.0
- seed: 42
- batch size: 1
- stopping: model EOS token or max_new_tokens

## Risk constructs
- CMR = true critical requirements predicted outside the critical set / true critical requirements.
- CAP = correct critical alerts / all predicted critical alerts.
- CSER = wrong exact subtype among true critical requirements / true critical requirements.
- RWE is true-class-only and is not a complete pairwise cost matrix.

## Models
- Qwen/Qwen3.5-4B @ 851bf6e806efd8d0a36b00ddf55e13ccb7b8cd0a (float16, no quantization, thinking disabled)
- google/gemma-4-E2B-it @ 70af34e20bd4b7a91f0de6b22675850c43922a03 (float16, no quantization, thinking disabled)
- TF-IDF + Logistic Regression
- TF-IDF + LinearSVC

The LLMs are not parameter- or architecture-matched; this is a practical checkpoint comparison.

## Kaggle instructions
1. Enable a GPU and Internet for the first run.
2. Add `HF_TOKEN` under Add-ons > Secrets if Hugging Face authentication is required.
3. Run all cells in order.
4. Use `LLM_LIMIT = None` for reported paper results.
5. Confirm that all point-estimate assertions and package checks pass.
6. Reproduce from a clean environment before minting the public release DOI.
